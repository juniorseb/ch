PACK LOGO MAMÉLODIE
====================

Contenu :

SVG (vectoriel, à utiliser en priorité — qualité illimitée, éditable) :
- mamelodie-logo-fond-clair.svg      → logo complet, texte foncé, pour fonds clairs
- mamelodie-logo-fond-sombre.svg     → logo complet, texte clair, pour fonds noirs/sombres
- mamelodie-icone.svg                → icône seule (7 barres), sans texte
- mamelodie-icone-simplifiee.svg     → icône seule (3 barres), pour petites tailles

PNG (raster, prêts à l'emploi) :
- mamelodie-logo-fond-clair.png      → haute résolution (x3)
- mamelodie-logo-fond-sombre.png     → haute résolution (x3)
- mamelodie-icone.png                → 1024x1024, pour app icon / réseaux sociaux
- mamelodie-icone-simplifiee.png     → 1024x1024
- mamelodie-favicon-32.png           → 32x32, prêt pour favicon.ico

Couleurs de marque :
- Orange accent : #F97316
- Noir badge    : #0E0E12
- Texte clair   : #F5F3EE
- Texte foncé   : #16161A

Police : Poppins (700 / Bold), via Google Fonts.
Les fichiers SVG chargent automatiquement la police en ligne (@import Google Fonts).
Si tu ouvres les SVG hors ligne ou dans un outil qui bloque les imports externes,
le texte peut s'afficher dans une police de secours — ouvre-les dans un navigateur
connecté ou remplace la police localement dans ton éditeur (Figma, Illustrator, Inkscape).

Note pour l'app icon (App Store / Play Store) :
Les stores demandent souvent un PNG 1024x1024 sans coins arrondis pré-appliqués
(le système applique le masque lui-même). Si besoin, redemande une version
"full-bleed" sans le rx du badge.
